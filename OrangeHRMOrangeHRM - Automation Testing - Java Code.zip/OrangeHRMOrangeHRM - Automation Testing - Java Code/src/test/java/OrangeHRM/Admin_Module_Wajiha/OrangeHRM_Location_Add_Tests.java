package OrangeHRM.Admin_Module_Wajiha;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.*;

import OrangeHRM.Admin_Module_Ahmed.OrangeHRM_Test_Base;

public class OrangeHRM_Location_Add_Tests extends OrangeHRM_Test_Base {

    private OrangeHRM_Locations locPage;

    @BeforeClass
    public void setupClass() {
        // تسجيل الدخول مباشرة
        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        locPage = new OrangeHRM_Locations(driver);
    }

    @Test(priority = 1, description = "Check validation when required fields are empty")
    public void testEmptyFields() {
        locPage.openAddForm();
        locPage.setName("");
        locPage.selectCountry("");
        locPage.clickSave();
        Assert.assertTrue(locPage.isRequiredMsgVisible(), "Required field validation failed!");
    }

    @Test(priority = 2, description = "Verify adding a new location with valid data")
    public void testValidLocation() {
        locPage.openAddForm();
        locPage.setName("TorontoHQ");
        locPage.selectCountry("Canada");
        locPage.clickSave();
        Assert.assertTrue(locPage.getToastMessage().contains("Successfully Saved"), "Location not saved!");
    }

    @Test(priority = 3, description = "Check system behavior when adding duplicate location")
    public void testDuplicateLocation() {
        locPage.openAddForm();
        locPage.setName("TorontoHQ");
        locPage.selectCountry("Canada");
        locPage.clickSave();
        Assert.assertTrue(locPage.isExistMsgVisible(), "Duplicate validation not triggered!");
    }

    @AfterClass
    public void tearDownClass() throws InterruptedException {
        driver.findElement(By.xpath("//p[@class='oxd-userdropdown-name']")).click();
        driver.findElement(By.xpath("//a[text()='Logout']")).click();
        Thread.sleep(1000);
    }
}
