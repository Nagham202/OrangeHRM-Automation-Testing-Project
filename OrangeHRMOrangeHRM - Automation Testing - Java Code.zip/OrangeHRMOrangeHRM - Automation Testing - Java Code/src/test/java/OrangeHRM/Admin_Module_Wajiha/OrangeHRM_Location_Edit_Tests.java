package OrangeHRM.Admin_Module_Wajiha;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.*;

import OrangeHRM.Admin_Module_Ahmed.OrangeHRM_Test_Base;

public class OrangeHRM_Location_Edit_Tests extends OrangeHRM_Test_Base {

    private OrangeHRM_Locations_Editor editPage;

    @BeforeClass
    public void setupClass() {
        // تسجيل الدخول مباشرة
        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        editPage = new OrangeHRM_Locations_Editor(driver);
    }

    @Test(priority = 1, description = "Check editing with blank mandatory fields shows error")
    public void testEditWithBlanks() {
        editPage.openLocationsPage();
        editPage.selectEdit(0);
        editPage.updateName("");
        editPage.clickSave();
        Assert.assertTrue(editPage.isErrorShown(), "Error message not displayed when fields are blank");
    }

    @Test(priority = 2, description = "Verify Cancel button on Edit form")
    public void testCancelEdit() {
        editPage.openLocationsPage();
        editPage.selectEdit(0);
        editPage.clickCancel();
        Assert.assertTrue(editPage.isCancelEnabled(), "Cancel button is not enabled!");
    }

    @Test(priority = 3, description = "Verify valid Location update")
    public void testValidEdit() {
        editPage.openLocationsPage();
        editPage.selectEdit(0);
        editPage.updateName("NewEgypt");
        editPage.updateCountry("Egypt");
        editPage.clickSave();
        Assert.assertTrue(editPage.getToastMessage().contains("Successfully Updated"), "Update was not successful!");
    }

    @AfterClass
    public void tearDownClass() throws InterruptedException {
        driver.findElement(By.xpath("//p[@class='oxd-userdropdown-name']")).click();
        driver.findElement(By.xpath("//a[text()='Logout']")).click();
        Thread.sleep(1000);
    }
}
