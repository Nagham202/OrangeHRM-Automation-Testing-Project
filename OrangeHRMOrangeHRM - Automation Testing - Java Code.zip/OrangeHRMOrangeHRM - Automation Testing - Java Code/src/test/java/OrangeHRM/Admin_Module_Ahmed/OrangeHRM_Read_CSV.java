package OrangeHRM.Admin_Module_Ahmed; // Defines the package for this class

import org.testng.annotations.DataProvider; // TestNG annotation for providing test data
import java.io.BufferedReader; // Reads text from input stream efficiently
import java.io.IOException; // Exception handling for I/O operations
import java.io.InputStream; // Represents an input stream of bytes
import java.io.InputStreamReader; // Converts bytes (InputStream) into characters
import java.util.ArrayList; // Dynamic list to store data
import java.util.List; // Interface for list collections

// Class responsible for reading CSV file and supplying data to TestNG tests
public class OrangeHRM_Read_CSV extends OrangeHRM_Test_Base {

	// ========================================================
	// DataProvider: Login Test Data
	// ========================================================
	@DataProvider(name = "Login_Test_Data")
	public Object[][] getCSVTestData_login() throws IOException {
		List<Object[]> data = new ArrayList<>(); // List to hold rows of test data

		InputStream isThread = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("OrangeHRM_Data/OrangeHRM_Login.csv"); // Load CSV file

		BufferedReader buffR = new BufferedReader(new InputStreamReader(isThread)); // Read CSV
		String line; // Variable to store each line read from the file
		boolean firstLine = true; // Flag to skip the header row

		while ((line = buffR.readLine()) != null) {
			if (firstLine) { // Skip header
				firstLine = false;
				continue;
			}

			String[] values = line.split(",", -1); // Split CSV line by commas

			String username = values[0]; // First column = username
			String password = values[1]; // Second column = password
			boolean expected = Boolean.parseBoolean(values[2].trim()); // Third column = expected result

			data.add(new Object[] { username, password, expected }); // Add row to list
		}

		return data.toArray(new Object[0][]); // Convert List<Object[]> to 2D array
	}

	// ========================================================
	// DataProvider: Reset Password Test Data
	// ========================================================
	@DataProvider(name = "Reset_Password_Test_Data")
	public Object[][] getCSVTestData_resetPassword() throws IOException {
		List<Object[]> data = new ArrayList<>(); // List to hold rows of test data

		InputStream isThread = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("OrangeHRM_Data/OrangeHRM_Reser_Password.csv"); // Load CSV file

		BufferedReader buffR = new BufferedReader(new InputStreamReader(isThread)); // Read CSV
		String line; // Variable to store each line read from the file
		boolean firstLine = true; // Flag to skip the header row

		while ((line = buffR.readLine()) != null) {
			if (firstLine) { // Skip header
				firstLine = false;
				continue;
			}

			String[] values = line.split(",", -1); // Split CSV line by commas

			String username = values[0]; // First column = username
			boolean expected = Boolean.parseBoolean(values[1].trim()); // Second column = expected result

			data.add(new Object[] { username, expected }); // Add row to list
		}

		return data.toArray(new Object[0][]); // Convert List<Object[]> to 2D array
	}

	// ========================================================
	// DataProvider: Search Test Data
	// ========================================================
	@DataProvider(name = "Search_Test_Data")
	public Object[][] getCSVTestData_search() throws IOException {
		List<Object[]> data = new ArrayList<>(); // List to hold rows of test data

		InputStream isThread = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("OrangeHRM_Data/OrangeHRM_Search.csv"); // Load CSV file

		BufferedReader buffR = new BufferedReader(new InputStreamReader(isThread)); // Read CSV
		String line; // Variable to store each line read from the file
		boolean firstLine = true; // Flag to skip the header row

		while ((line = buffR.readLine()) != null) {
			if (firstLine) { // Skip header
				firstLine = false;
				continue;
			}

			String[] values = line.split(",", -1); // Split CSV line by commas

			String username = values[0]; // First column = username
			String userRole = values[1]; // Second column = userRole
			String employeeName = values[2]; // Third column = empName
			String status = values[3]; // Fourth column = status
			boolean expected = Boolean.parseBoolean(values[4].trim()); // Fifth column = expected result

			data.add(new Object[] { username, userRole, employeeName, status, expected }); // Add row to list
		}

		return data.toArray(new Object[0][]); // Convert List<Object[]> to 2D array
	}

	// ========================================================
	// DataProvider: Add User Test Data
	// ========================================================
	@DataProvider(name = "Add_Test_Data")
	public Object[][] getCSVTestData_add() throws IOException {
		List<Object[]> data = new ArrayList<>(); // List to hold rows of test data

		InputStream isThread = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("OrangeHRM_Data/OrangeHRM_Add.csv"); // Load CSV file

		BufferedReader buffR = new BufferedReader(new InputStreamReader(isThread)); // Read CSV
		String line; // Variable to store each line read from the file
		boolean firstLine = true; // Flag to skip the header row

		while ((line = buffR.readLine()) != null) {
			if (firstLine) { // Skip header
				firstLine = false;
				continue;
			}

			String[] values = line.split(",", -1); // Split CSV line by commas

			String userRole = values[0]; // First column = userRole
			String employeeName = values[1]; // Second column = employeeName
			String status = values[2]; // Third column = status
			String username = values[3]; // Fourth column = username
			String password = values[4]; // Fifth column = password
			String confirmPassword = values[5]; // sixth column = confirmPassword
			boolean expected = Boolean.parseBoolean(values[6].trim()); // seventh column = expected result

			data.add(new Object[] { userRole, employeeName, status, username, password, confirmPassword, expected }); // Add
																														// row
																														// to
																														// list
		}

		return data.toArray(new Object[0][]); // Convert List<Object[]> to 2D array
	}

	// ========================================================
	// DataProvider: Edit User Test Data
	// ========================================================
	@DataProvider(name = "Edit_Test_Data")
	public Object[][] getCSVTestData_edit() throws IOException {
		List<Object[]> data = new ArrayList<>(); // List to hold rows of test data

		InputStream isThread = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("OrangeHRM_Data/OrangeHRM_Edit.csv"); // Load CSV file

		BufferedReader buffR = new BufferedReader(new InputStreamReader(isThread)); // Read CSV
		String line; // Variable to store each line read from the file
		boolean firstLine = true; // Flag to skip the header row

		while ((line = buffR.readLine()) != null) {
			if (firstLine) { // Skip header
				firstLine = false;
				continue;
			}

			String[] values = line.split(",", -1); // Split CSV line by commas

			String userRole = values[0]; // Second column = new userRole
			String employeeName = values[1]; // Third column = new employeeName
			String status = values[2]; // Fourth column = new status
			String username = values[3]; // First column = username to search
			String password = values[4]; // Fifth column = new password
			String confirmPassword = values[5]; // sixth column = new confirmPassword
			boolean expected = Boolean.parseBoolean(values[6].trim()); // Fifth column = expected result

			data.add(new Object[] { userRole, employeeName, status, username, password, confirmPassword, expected }); // Add
																														// row
																														// to
																														// list
		}

		return data.toArray(new Object[0][]); // Convert List<Object[]> to 2D array
	}
}