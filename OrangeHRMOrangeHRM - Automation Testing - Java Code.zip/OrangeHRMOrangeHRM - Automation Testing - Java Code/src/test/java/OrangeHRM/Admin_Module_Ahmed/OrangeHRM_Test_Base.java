package OrangeHRM.Admin_Module_Ahmed;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;

// Base test class for OrangeHRM tests
public class OrangeHRM_Test_Base {
	protected WebDriver driver; // WebDriver instance for browser automation

	// Base URL of the OrangeHRM demo site
	private static String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";

	// ========================================================
	// Getter for base URL
	// ========================================================
	public String getBaseUrl() {
		return baseUrl;
	}

	// ========================================================
	// Setup method: runs before all tests
	// ========================================================
	@BeforeTest
	public void setup() {
		WebDriverManager.chromedriver().setup(); // Automatically downloads and sets up ChromeDriver
		driver = new ChromeDriver(); // Launches Chrome browser
		driver.manage().window().maximize(); // Maximizes browser window
		driver.get(baseUrl); // Opens the OrangeHRM login page
	}

	// ========================================================
	// Tear down method: runs after all tests
	// ========================================================
	@AfterTest
	public void tearDown() throws InterruptedException {
		if (driver != null) { // Ensure driver is initialized
			Thread.sleep(2000); // Small delay before closing
			driver.quit(); // Close all browser windows and end WebDriver session
		}
	}
}