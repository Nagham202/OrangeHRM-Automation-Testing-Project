package OrangeHRM.Admin_Module_Wajiha;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
public class OrangeHRM_Locations_Editor {
   WebDriver driver;
   WebDriverWait wait;
   private By adminMenu = By.xpath("//a//span[text()='Admin']");
   private By orgMenu = By.xpath("//li[contains(@class,'oxd-topbar-body-nav-tab')]//span[text()='Organization']");
   private By locationsLink = By.xpath("//a[normalize-space()='Locations']");
   private By editIcons = By.cssSelector("i.bi-pencil-fill");
   private By nameField = By.xpath("(//input[@class='oxd-input oxd-input--active'])[2]");
   private By cityField = By.xpath("(//input[@class='oxd-input oxd-input--active'])[3]");
   private By stateField = By.xpath("(//input[@class='oxd-input oxd-input--active'])[4]");
   private By zipField = By.xpath("(//input[@class='oxd-input oxd-input--active'])[5]");
   private By countryDropdown = By.xpath("//div[contains(@class,'oxd-select-text--after')]");
   private By phoneField = By.xpath("(//input[@class='oxd-input oxd-input--active'])[6]");
   private By addressBox = By.xpath("(//textarea[@class='oxd-textarea'])[1]");
   private By notesBox = By.xpath("(//textarea[@class='oxd-textarea'])[2]");
   private By saveBtn = By.xpath("//button[@type='submit']");
   private By cancelBtn = By.xpath("(//button[@type='button'])[4]");
   private By requiredMsg = By.xpath("//span[text()='Required']");
   private By toastMsg = By.xpath("//div[contains(@id,'oxd-toaster_')]");
   private By phoneFormatError = By.xpath("//span[text()='Allows numbers and only + - / ( )']");
   public OrangeHRM_Locations_Editor(WebDriver driver) {
       this.driver = driver;
       this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
   }
   public void openLocationsPage() {
       wait.until(ExpectedConditions.elementToBeClickable(adminMenu)).click();
       wait.until(ExpectedConditions.elementToBeClickable(orgMenu)).click();
       wait.until(ExpectedConditions.elementToBeClickable(locationsLink)).click();
   }
   public void selectEdit(int rowIndex) {
       wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(editIcons, rowIndex));
       driver.findElements(editIcons).get(rowIndex).click();
   }
   public void updateName(String value) {
       clearAndType(nameField, value);
   }
   public void updateCity(String value) {
       clearAndType(cityField, value);
   }
   public void updateState(String value) {
       clearAndType(stateField, value);
   }
   public void updateZip(String value) {
       clearAndType(zipField, value);
   }
   public void updateCountry(String country) {
       driver.findElement(countryDropdown).click();
       List<WebElement> options = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@role='option']")));
       for (WebElement option : options) {
           if (option.getText().equals(country)) {
               option.click();
               break;
           }
       }
   }
   public void updatePhone(String value) {
       clearAndType(phoneField, value);
   }
   public void updateAddress(String value) {
       clearAndType(addressBox, value);
   }
   public void updateNotes(String value) {
       clearAndType(notesBox, value);
   }
   public void clickSave() {
       wait.until(ExpectedConditions.elementToBeClickable(saveBtn)).click();
   }
   public void clickCancel() {
       wait.until(ExpectedConditions.elementToBeClickable(cancelBtn)).click();
   }
   public boolean isErrorShown() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(requiredMsg)).isDisplayed();
   }
   public String getToastMessage() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(toastMsg)).getText().trim();
   }
   public boolean isPhoneFormatError() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(phoneFormatError)).isDisplayed();
   }
   public boolean isCancelEnabled() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(cancelBtn)).isEnabled();
   }
   private void clearAndType(By locator, String value) {
       WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
       element.click();
       element.sendKeys(Keys.CONTROL + "a");
       element.sendKeys(Keys.DELETE);
       element.sendKeys(value);
   }
}