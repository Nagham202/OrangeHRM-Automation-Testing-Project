package OrangeHRM.Admin_Module; // Defines the package location of this class

import java.time.Duration; // For specifying time durations in waits
import org.openqa.selenium.By; // For locating elements on a webpage
import org.openqa.selenium.WebDriver; // For controlling the browser
import org.openqa.selenium.WebElement; // For handling HTML elements
import org.openqa.selenium.support.ui.ExpectedConditions; // For wait conditions
import org.openqa.selenium.support.ui.WebDriverWait; // For explicit waits

// Page Object Model (POM) class for OrangeHRM Login Page
public class OrangeHRM_Login_Page {

	private WebDriver driver; // WebDriver instance to control the browser

	// --- Locators for login elements ---
	private By usernameInput = By
			.xpath("//div[@id='app']/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input"); // Username
																											// field
	private By passwordInput = By
			.xpath("//div[@id='app']/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input"); // Password
																											// field
	private By loginButton = By.xpath("//div[@id='app']/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button"); // Login
																													// button
	private By checkIfLoggedIn = By.xpath("//div[@id='app']/div[1]/div[1]/header/div[1]/div[1]"); // Header after login
	private By forgotYourPassword = By.xpath("//div[@id='app']/div[1]/div/div[1]/div/div[2]/div[2]/form/div[4]/p"); // "Forgot
																													// your
																													// password?"
																													// link

	// --- Locators for reset password page ---
	private By resetPasswordUsername = By.xpath("//div[@id='app']/div[1]/div[1]/div/form/div[1]/div/div[2]/input"); // Username
																													// field
																													// on
																													// reset
																													// page
	private By resetPasswordButton = By.xpath("//div[@id='app']/div[1]/div[1]/div/form/div[2]/button[2]"); // Reset
																											// password
																											// button
	private By checkIfPasswordLinkSent = By.xpath("//div[@id='app']/div[1]/div[1]/div/h6"); // Message after reset
	private By backToLoginButton = By.xpath("//div[@id='app']/div[1]/div[1]/div/form/div[2]/button[1]"); // "Back to
																											// login"
																											// button

	// --- Locators for login page check ---
	private By checkIfAtLoginPage = By
			.xpath("//div[@id='app' and contains(normalize-space(), 'Login')]/div[1]/div/div[1]/div/div[2]/h5"); // Login
																													// page
																													// check

	// --- Locators for footer and social media ---
	private By checkFooterCopyRightTextValue = By.xpath(
			"//div[@id='app' and contains(normalize-space(), '2025')]/div[1]/div/div[1]/div/div[2]/div[3]/div[2]/p[2]"); // Footer
																															// copyright
																															// text
	private By checkFooterYouTubeIcon = By.xpath("//div[@id='app']/div[1]/div/div[1]/div/div[2]/div[3]/div[1]/a[4]"); // YouTube
																														// icon
	private By checkFooterTwitterIcon = By.xpath("//div[@id='app']/div[1]/div/div[1]/div/div[2]/div[3]/div[1]/a[3]"); // Twitter
																														// icon
	private By checkFooterFacebookIcon = By.xpath("//div[@id='app']/div[1]/div/div[1]/div/div[2]/div[3]/div[1]/a[2]"); // Facebook
																														// icon
	private By checkFooterLinkedInIcon = By.xpath("//div[@id='app']/div[1]/div/div[1]/div/div[2]/div[3]/div[1]/a[1]"); // LinkedIn
																														// icon

	// --- Constructor ---
	public OrangeHRM_Login_Page(WebDriver driver) {
		this.driver = driver; // Assign the passed WebDriver instance
	}

	// --- Basic actions ---

	// Enter username in login field
	public void enterUsername(String username) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait for element
		wait.until(ExpectedConditions.visibilityOfElementLocated(usernameInput)); // Wait until visible
		driver.findElement(usernameInput).clear(); // Clear existing text
		driver.findElement(usernameInput).sendKeys(username); // Enter username
	}

	// Enter password in login field
	public void enterPassword(String password) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.visibilityOfElementLocated(passwordInput)); // Wait until visible
		driver.findElement(passwordInput).clear(); // Clear existing text
		driver.findElement(passwordInput).sendKeys(password); // Enter password
	}

	// Click login button
	public void clickLogin() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(loginButton)); // Wait until clickable
		driver.findElement(loginButton).click(); // Click login
	}

	// Click "Forgot your password?" link
	public void clickForgotYourPassword() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.elementToBeClickable(forgotYourPassword)); // Wait until clickable
		driver.findElement(forgotYourPassword).click(); // Click link
	}

	// Enter username on reset password page
	public void enterResetPasswordUsername(String username) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(resetPasswordUsername)); // Wait until visible
		driver.findElement(resetPasswordUsername).clear(); // Clear text
		driver.findElement(resetPasswordUsername).sendKeys(username); // Enter username
	}

	// Click reset password button
	public void clickResetPassword() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.elementToBeClickable(resetPasswordButton)); // Wait until clickable
		driver.findElement(resetPasswordButton).click(); // Click button
	}

	// Click "Back to login" button
	public void clickBackToLogin() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.elementToBeClickable(backToLoginButton)); // Wait until clickable
		driver.findElement(backToLoginButton).click(); // Click button
	}

	// --- Checks / validations ---

	// Check if user is logged in successfully
	public boolean isLoggedIn() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement dashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(checkIfLoggedIn)); // Wait
																												// for
																												// header
			return dashboard.isDisplayed(); // Return true if visible
		} catch (Exception e) {
			return false; // Return false if not found
		}
	}

	// Check if user is at login page
	public boolean isAtLoginPage() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement atLoginPage = wait.until(ExpectedConditions.visibilityOfElementLocated(checkIfAtLoginPage));
			return atLoginPage.isDisplayed(); // Return true if visible
		} catch (Exception e) {
			return false;
		}
	}

	// Check if password reset link is sent
	public boolean isPasswordResetLinkSent() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement passwordLinkSent = wait
					.until(ExpectedConditions.visibilityOfElementLocated(checkIfPasswordLinkSent));
			return passwordLinkSent.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	// Overloaded method with string argument
	public boolean isPasswordResetLinkSent(String string) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement passwordLinkSent = wait
					.until(ExpectedConditions.visibilityOfElementLocated(checkIfPasswordLinkSent));
			return passwordLinkSent.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	// Check if footer copyright text is displayed
	public boolean isFooterCopyRightTextDisplayed() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement footerText = wait
					.until(ExpectedConditions.visibilityOfElementLocated(checkFooterCopyRightTextValue));
			return footerText.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	// Check if footer YouTube icon is visible and clickable
	public boolean isFooterYouTubeIconDisplayedAndClickable() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement youtubeIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(checkFooterYouTubeIcon));
			return youtubeIcon.isDisplayed() && youtubeIcon.isEnabled(); // Visible & clickable
		} catch (Exception e) {
			return false;
		}
	}

	// Check if footer Twitter icon is visible and clickable
	public boolean isFooterTwitterIconDisplayedAndClickable() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement twitterIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(checkFooterTwitterIcon));
			return twitterIcon.isDisplayed() && twitterIcon.isEnabled();
		} catch (Exception e) {
			return false;
		}
	}

	// Check if footer Facebook icon is visible and clickable
	public boolean isFooterFacebookIconDisplayedAndClickable() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement facebookIcon = wait
					.until(ExpectedConditions.visibilityOfElementLocated(checkFooterFacebookIcon));
			return facebookIcon.isDisplayed() && facebookIcon.isEnabled();
		} catch (Exception e) {
			return false;
		}
	}

	// Check if footer LinkedIn icon is visible and clickable
	public boolean isFooterLinkedInIconDisplayedAndClickable() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement linkedInIcon = wait
					.until(ExpectedConditions.visibilityOfElementLocated(checkFooterLinkedInIcon));
			return linkedInIcon.isDisplayed() && linkedInIcon.isEnabled();
		} catch (Exception e) {
			return false;
		}
	}

	// --- Combined actions ---

	// Perform full login: enter username, password, click login
	public void login(String username, String password) {
		enterUsername(username); // Enter username
		enterPassword(password); // Enter password
		clickLogin(); // Click login
	}

	// Perform full reset password: click forgot + enter username + reset
	public void resetPassword(String username) {
		clickForgotYourPassword(); // Click forgot password link
		enterResetPasswordUsername(username); // Enter username
		clickResetPassword(); // Click reset
	}

	// Navigate back to login page from reset password page
	public boolean backToLogin() {
		clickForgotYourPassword(); // Click forgot password
		enterResetPasswordUsername("Admin"); // Enter username
		clickResetPassword(); // Click reset
		clickBackToLogin(); // Click back to login
		return isAtLoginPage(); // Check if at login page
	}

	// Verify footer text and social media icons
	public boolean verifyFooterAndSocialMediaLinks() {
		return isFooterCopyRightTextDisplayed() && isFooterYouTubeIconDisplayedAndClickable()
				&& isFooterTwitterIconDisplayedAndClickable() && isFooterFacebookIconDisplayedAndClickable()
				&& isFooterLinkedInIconDisplayedAndClickable(); // All must be true
	}

}